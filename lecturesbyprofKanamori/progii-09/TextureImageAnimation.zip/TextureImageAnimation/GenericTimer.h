#ifndef __GENERIC_TIMER_H__
#define __GENERIC_TIMER_H__

void StartTimer(void);

double GetTime(void);

double GetRapTime(double prevTime);

#endif


#include <stdio.h> //標準のヘッダファイルは普通pragma onceが書いてあるっぽい。
#include <string.h>
#include "kadai5.h"
#define MAX_IMAGE_SIZE 512
//#define debugA
//#define debugB
//#define debugC
#define debugE




int main(int argc, char *argv[]){
  
  int w, h, dummy; //for file access
  char header[3];
  FILE *fp1;

  int i, j; // for manipulating
  unsigned char rgb[3]; //r:0 g:1 b:2

  unsigned char buf1[1000];
  unsigned char buf2[1000];// for buffer.
  unsigned char colorBuf[1000];
  unsigned char grayBuf[1000];
  unsigned char sepBuf[1000];
  unsigned char negBuf[1000];
  
#ifdef debugA
  fp1 = fopen(argv[1], "rb");
  fscanf(fp1, "%s\n%d %d\n%d\n", header, &w, &h, &dummy);

  if(fp1 == NULL){
    printf("Error: file not found.\n");
    return -1;
  }

  printf("image size: %dx%d\n", w, h);

  if(header[1] == 0 || header[1] == 1 || header[1] == 2){
    for(i=0; i<h; i++){
      for(j=0; j<w; j++){
	fscanf(fp1, "%c %c %c", &rgb[0], &rgb[1], &rgb[2]);
	printf("(%d,%d) rgb = (%d, %d, %d)\n", j, i, (unsigned int)rgb[0], (unsigned int)rgb[1], (unsigned int)rgb[2]);
      }
    }
  }
  else{
    for(i=0; i<h; i++){
      for(j=0; j<w; j++){
	fread(rgb, sizeof(unsigned char), 3, fp1);
	printf("(%d,%d) rgb = (%d, %d, %d)\n", j, i, (int)rgb[0], (int)rgb[1], (int)rgb[2]);
      }
    }
  }
#endif

#ifdef debugB
  if(load_pgm("checker4x4_ascii.pgm", &w, &h, buf1) == 1){  
    save_pgm("copyfile1.bin", w, h, buf1);
  }
  if(load_pgm("checker4x4_binary.pgm", &w, &h, buf2) == 1){  
    save_pgm("copyfile2.bin", w, h, buf2);
  }
#endif

#ifdef debugC
  if(load_ppm("color4x4_ascii.ppm", &w, &h, buf1) == 1){  
    save_pgm("copyfile3.bin", w, h, buf1);
  }
  if(load_ppm("color4x4_binary.ppm", &w, &h, buf2) == 1){  
    save_pgm("copyfile4.bin", w, h, buf2);
  }
#endif

#ifdef debugE
  color2gray(400, 400, colorBuf, grayBuf);


#endif
  
  

#ifdef debugA
  fclose(fp1);
#endif
  return 0;
}




#include <stdio.h>
#include <string.h>

void color2gray(int w, int h, unsigned char *colorBuf, unsigned char *grayBuf);


int main(){
  unsigned char colorBuf[1000000];
  unsigned char grayBuf[100];
  int w=400, h=400;
  
  printf("0");
  color2gray(w, h, colorBuf, grayBuf);
  return 0;}

void color2gray(int w, int h, unsigned char *colorBuf, unsigned char *grayBuf){
  FILE *fps;
  int i, dummy, c, count;

  printf("1");

  fps = fopen("sutehagegray.pgm", "wb+");

  if(fps == NULL){
    printf("Error: original file missing.\n");
    return 0;
  }
  
  
   //printf("%s ", header);
   //printf("%d", count);
  
  fprintf(fps, "P5\n%d %d\n%d\n", w, h, dummy);

    for(i=0; i<w*h*3; i++){
      fread((colorBuf), sizeof(unsigned char), 3, fpl);
       *(double *)(grayBuf) =0.298912 * *(double *)(colorBuf+i*3) + 0.586611 * *(double *)(colorBuf+1) + 0.114478 * *(double *)(colorBuf+2);
      fwrite(grayBuf, sizeof(unsigned char), 1, fps);
    }
      
  //  printf("3");
  
  
  //printf("%d %d , ", sizeof(buf), count);
  

  fclose(fps);
  fclose(fpl);
}
//void gray2sepia(int w, int h, unsigned char *grayBuf, unsigned char *sepiaBuf);
//void gray_negapos(int w, int h, unsigned char *posBuf, unsigned char *negBuf);

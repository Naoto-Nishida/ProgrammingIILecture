#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#define NUMQUIZ 1024
#define itemsize 5

typedef struct {
  char question[256];
  char item[itemsize][256];
} QuizData;



int main(int argc, char *argv[]){
  QuizData quiz[NUMQUIZ];
  int i=0, num, answer=1;
  FILE *fp;
  int k, j, Ans=0;
  char *t;

  printf("e");

  if((fp = fopen(argv[1], "rb")) == NULL){
    printf("File couldn't be opened.\n");
    return -1;
  }

  printf("d");
  
  if(argc != 2){
    printf("you've made a wrong command.\n");
    return -1;
  }

  while(fscanf(fp, "%[^,],%[^,],%[^,],%[^,],%[^,],%s", quiz[i].question, quiz[i].item[0], quiz[i].item[1], quiz[i].item[2], quiz[i].item[3], quiz[i].item[4]) != EOF){
    i++;
  }
  i--;
  num = i;
  printf("c");
  srand(time(NULL));

  for(i=0; i<num; i++){
    //answer = shuffle(quiz[i].item, itemsize);


    for(k=1;k<itemsize;k++)
      {
	// srand(time(NULL));
	j = rand()%itemsize;
	if(j==0){
	  *t = quiz[i].item[k];
	  strcpy(quiz[i].item[k], quiz[i].item[j]);
	  strcpy(quiz[i].item[j], *t);
	  Ans = k+1;
	      printf("b");
	}
	printf("a");
	*t = quiz[i].item[k];
	strcpy(quiz[i].item[k], quiz[i].item[j]);
	strcpy(quiz[i].item[j], *t);
      }
	
	
    fprintf(stdout, "Q%d: %s\n  1:%s 2:%s 3:%s 4:%s 5:%s\n", i+1, quiz[i].question, quiz[i].item[0], quiz[i].item[1], quiz[i].item[2], quiz[i].item[3], quiz[i].item[4]);
    fprintf(stdout, "A%d: %d\n\n", i+1, answer);
  }
    
  fclose(fp);
  return 0;
}
